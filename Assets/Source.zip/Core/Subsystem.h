#pragma once

#include <Core/Core.h>

namespace Yage
{
	// Forward declaration
	class Engine;

	class ISubsystem
	{
	private:

	protected:
		// Subsystem does not own the pointer.
		Engine* engine;

	public:
		ISubsystem(Engine* e);
		~ISubsystem();

		virtual const char* GetName() = 0;
		virtual bool Initialize() = 0;
		virtual void Destroy() = 0;
	};
}