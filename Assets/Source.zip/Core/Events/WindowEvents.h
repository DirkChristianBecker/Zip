#pragma once

#include <Core/Types.h>

namespace Yage
{
	struct QuitRequestedEvent
	{

	};

	struct WindowShownEvent
	{
	public:
		UInt32 SdlWindowId;
	};

	struct WindowHiddenEvent
	{
	public:
		UInt32 SdlWindowId;
	};

	struct WindowExposedEvent
	{
	public:
		UInt32 SdlWindowId;
	};

	struct WindowMovedEvent
	{
	public:
		UInt32 SdlWindowId;
		Int32 x;
		Int32 y;
	};

	struct WindowResizedEvent
	{
	public:
		UInt32 SdlWindowId;
		Int32 x;
		Int32 y;
	};

	struct WindowSizeChangedEvent
	{
	public:
		UInt32 SdlWindowId;
		Int32 x;
		Int32 y;
	};

	struct WindowMinimizedEvent
	{
	public:
		UInt32 SdlWindowId;
	};

	struct WindowMaximizedEvent
	{
	public:
		UInt32 SdlWindowId;
	};

	struct WindowRestoredEvent
	{
	public:
		UInt32 SdlWindowId;
	};

	struct WindowMouseEnteredEvent
	{
	public:
		UInt32 SdlWindowId;
	};

	struct WindowMouseLeftEvent
	{
	public:
		UInt32 SdlWindowId;
	};

	// keyboard focus
	struct WindowGainedFocusEvent
	{
	public:
		UInt32 SdlWindowId;
	};

	// keyboard focus
	struct WindowLostFocusEvent
	{
	public:
		UInt32 SdlWindowId;
	};

	struct WindowCloseEvent
	{
	public:
		UInt32 SdlWindowId;
	};
}