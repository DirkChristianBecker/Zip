#pragma once

#include<Core/Subsystem.h>
#include<entt/entt.hpp>

namespace Yage
{
	class Engine;
	class EventBus : public ISubsystem
	{
	private:
		entt::dispatcher bus;

	public:
		EventBus(Engine* e);

		virtual const char* GetName() { return "Event bus"; }
		virtual bool Initialize();
		virtual void Destroy();

		template<typename T> auto Sink() { return bus.sink<T>(); }
		template<typename T> void Trigger() { bus.trigger(T{ }); }
		template<typename T> void Trigger(T& t) { bus.trigger(t); } 

		template<typename T> void Enqueue() { bus.enqueue(T{ }); }
		template<typename T> void Enqueue(float delta_time) { bus.enqueue(T { delta_time }); }
		template<typename T> void Enqueue(UInt32 sdl_window_id) { bus.enqueue(T{ sdl_window_id }); }
		template<typename T> void Enqueue(T& t) { bus.enqueue(t); }
		

		template<typename Sink, auto Method, typename...Type>
		auto Connect(Type&&...value)
		{
			return bus.sink<Sink>().connect<Method>(std::forward<Type>(value)...);
		}

		template<typename Sink, auto Method, typename...Type>
		auto Disconnect(Type&&...value)
		{
			return bus.sink<Sink>().disconnect<Method>(std::forward<Type>(value)...);
		}

		inline void Update() { bus.update(); }
	};
}