#include "EventBus.h"
#include "Events.h"

namespace Yage
{
    EventBus::EventBus(Engine* e) : 
        ISubsystem(e)
    {

    }

    bool EventBus::Initialize()
    {
        // Call all events at least once to make sure event listeners can fire events themself.
        // 
        // This means: The eventbus has prepared queues for all event. Sending events means
        // iterating over all event queue so the vector that holds these queues cannot change.
        // But that is exactly what happens if we send an event that has not been send before.
        
        // Engine events
        bus.enqueue<UpdateInputsEvent>();
        bus.enqueue<UpdateEvent>(0.0f);
        bus.enqueue<RenderEvent>(0.0f);

        // Window events
        bus.enqueue<QuitRequestedEvent>();
        bus.enqueue<WindowShownEvent>((UInt32) 0);
        bus.enqueue<WindowHiddenEvent>((UInt32) 0);
        bus.enqueue<WindowExposedEvent>((UInt32) 0);
        bus.enqueue<WindowMovedEvent>(WindowMovedEvent{ (UInt32) 0, 0, 0 });
        bus.enqueue<WindowResizedEvent>(WindowResizedEvent{ (UInt32) 0, 0, 0 });
        bus.enqueue<WindowSizeChangedEvent>(WindowSizeChangedEvent{ (UInt32) 0, 0, 0 });
        bus.enqueue<WindowMinimizedEvent>((UInt32) 0);
        bus.enqueue<WindowMaximizedEvent>((UInt32) 0);
        bus.enqueue<WindowRestoredEvent>((UInt32) 0);
        bus.enqueue<WindowMouseEnteredEvent>((UInt32) 0);
        bus.enqueue<WindowMouseLeftEvent>((UInt32) 0);
        bus.enqueue<WindowGainedFocusEvent>((UInt32) 0);
        bus.enqueue<WindowLostFocusEvent>((UInt32) 0);
        bus.enqueue<WindowCloseEvent>((UInt32) 0);

        // Empty all queues
        bus.update();

        return true;
    }

    void EventBus::Destroy()
    {

    }
}
