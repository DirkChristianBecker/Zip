#pragma once

namespace Yage
{
	struct UpdateInputsEvent
	{

	};

	struct UpdateEvent
	{
	public:
		float DeltaTime;
	};

	struct RenderEvent
	{
	public:
		float DeltaTime;
	};
}