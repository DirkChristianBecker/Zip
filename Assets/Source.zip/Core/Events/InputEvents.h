#pragma once

namespace Yage
{

}