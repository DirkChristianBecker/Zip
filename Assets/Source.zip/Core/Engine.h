#pragma once

#include <Core/Types.h>
#include <Core/Singleton.h>
#include <Core/Subsystem.h>
#include <Core/Events/Events.h>

#include <IO/Logger.h>

// Subsystems
#include <IO/FileSystem.h>
#include <Core/Events/EventBus.h>
#include <Input/InputManager.h>

// SDL headers must not end up in engine header file! Somehow the linker does not like that...

#include <typeinfo>

#define EVENTBUS() ::Yage::Engine::Get().GetSubsystem<EventBus>()
#define FILESYSTEM() ::Yage::Engine::Get().GetSubsystem<FileSystem>()

namespace Yage
{
	class Engine : public ThreadSafeSingleton<Engine>
	{
	private:
		HashMap<Size, SharedPtr<ISubsystem>> m_subsystems;
		
		FileSystem* m_Filesystem;
		EventBus* m_Eventbus;
		InputManager* m_Inputmanager;

		bool m_isRunning;

	public:
		static Engine& Get() { return ThreadSafeSingleton<Engine>::Get(); }

		Engine();
		~Engine();

		bool IsRunning() const { return m_isRunning; }

		template<typename T> 
		T* RegisterSubsystem()
		{
			auto id = typeid(T).hash_code();
			auto it = m_subsystems.find(id);
			if (it != m_subsystems.end())
			{
				LOG_WARN("Subsystem '{0}' already registered.", typeid(T).name());
				return reinterpret_cast<T*>(it->second.get());
			}

			auto system = MakeShared<T>(this);
			m_subsystems.insert(std::make_pair(id, system));

			return reinterpret_cast<T*>(system.get());
		}

		template<typename T> 
		T* GetSubsystem() const
		{
			auto id = typeid(T).hash_code();
			auto it = m_subsystems.find(id);
			ASSERT(it != m_subsystems.end(), "Subsystem does not exist. Register it first!");

			return reinterpret_cast<T*>(it->second.get());
		}

		template<> FileSystem*		GetSubsystem<FileSystem>() const { return m_Filesystem; }
		template<> EventBus*		GetSubsystem<EventBus>() const { return m_Eventbus; }
		template<> InputManager*	GetSubsystem<InputManager>() const { return m_Inputmanager; }

		virtual bool Initialize();
		virtual void Run();
		virtual void Stop(QuitRequestedEvent e);
		virtual void TearDown();
	};
}