#include <Core/Engine.h>

#include <Graphics/WindowManager.h>


namespace Yage
{
	Engine::Engine() :
		m_Eventbus(nullptr),
		m_Filesystem(nullptr),
		m_Inputmanager(nullptr),
		m_isRunning(false)
	{
	}

	Engine::~Engine()
	{
		
	}

	bool Engine::Initialize()
	{
		std::lock_guard<std::mutex> lock(m_mConstructed);
		ASSERT(m_pInstance == nullptr, "Engine started multiple times!");
		m_pInstance = this;

		LOG_INFO("Engine created and logger is in place. Lets go...");

		m_isRunning = false;

		/// Core
		m_Eventbus = RegisterSubsystem<EventBus>();
		m_Eventbus->Initialize();

		m_Filesystem = RegisterSubsystem<FileSystem>();
		m_Inputmanager = RegisterSubsystem<InputManager>();

		RegisterSubsystem<WindowManager>();		// Initializes SDL

		LOG_INFO("Starting Yage...");
		LOG_INFO("Initializing subsystems...");
		for (auto it = m_subsystems.begin(); it != m_subsystems.end(); it++)
		{
			if (it->second.get() == m_Eventbus)
			{
				LOG_INFO("Eventbus already initialized.");
				continue;
			}

			LOG_INFO("Starting {0} ...", it->second->GetName());
			if (!it->second->Initialize())
			{
				LOG_INFO("Could not initialize '{0}'. Stop.", it->second->GetName());
				return false;
			}
		}
		LOG_INFO("...subsystems initialized");

		/// Register events.
		m_Eventbus->Connect<QuitRequestedEvent, &Engine::Stop>(this);

		return true;
	}

	void Engine::Run()
	{
		m_isRunning = true;

		UpdateEvent u { 1.0f };
		UpdateInputsEvent inputs { };

		while (m_isRunning)
		{
			m_Eventbus->Update();

			// Poll SDL Events
			m_Eventbus->Trigger(inputs);

			// Update logic
			m_Eventbus->Trigger(u);
		}
	}

	void Engine::Stop(QuitRequestedEvent e)
	{
		LOG_INFO("Stopping engine...");
		m_isRunning = false;
	}

	void Engine::TearDown()
	{
		m_Eventbus->Disconnect<QuitRequestedEvent, &Engine::Stop>(this);

		LOG_INFO("Shutting down...");
		for(auto it = m_subsystems.begin(); it != m_subsystems.end(); it++)
		{
			it->second->Destroy();
		}

		m_subsystems.clear();

		m_Eventbus = nullptr;
		m_Filesystem = nullptr;
		m_Inputmanager = nullptr;

		LOG_INFO("...subsystems shutdown.");

		std::lock_guard<std::mutex> lock(m_mConstructed);
		m_pInstance = nullptr;
	}
}