#include <Core/Subsystem.h>
#include <Core/Engine.h>

namespace Yage
{
	ISubsystem::ISubsystem(Engine* e)
		: engine(e)
	{

	}

	ISubsystem::~ISubsystem()
	{

	}
}