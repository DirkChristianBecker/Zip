#pragma once

#include <Core/Types.h>

// Break
#if YAGE_WINDOWS
    #define YAGE_BREAK() __debugbreak();
#else
    #define YAGE_BREAK() raise(SIGTRAP);
#endif

// C-Tor
#define NONCOPYABLE(type_identifier)                             \
    type_identifier(const type_identifier&)            = delete; \
    type_identifier& operator=(const type_identifier&) = delete;


// Assertions
#define ASSERT(condition, ...)     \
{                                           \
    if(!(condition))                        \
    {                                       \
        LOG_ERROR("Assertion Failed");      \
        LOG_ERROR(__VA_ARGS__);             \
        YAGE_BREAK();                       \
    }                                       \
}

// Non copyable
#define NONCOPYABLE(type_identifier)                             \
    type_identifier(const type_identifier&)            = delete; \
    type_identifier& operator=(const type_identifier&) = delete;