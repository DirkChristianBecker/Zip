#pragma once

#include <unordered_map>
#include <string>
#include <memory>
#include <iostream>
#include <string_view>
#include <stdarg.h>
#include <sstream>
#include <vector>
#include <iterator>
#include <cinttypes>
#include <utility>
#include <filesystem>

#include <glm/glm.hpp>

namespace Yage
{
	// Pointer
	template<typename T> using SharedPtr = std::shared_ptr<T>;
	template<typename T> using WeakPtr = std::weak_ptr<T>;
	template<typename T> using UniquePtr = std::unique_ptr<T>;

	// container
	template<typename T, typename S> using HashMap = std::unordered_map<T, S>;
	template<typename T, typename S> using Pair = std::pair<T, S>;
	template<typename T> using Vector = std::vector<T>;

	// String
	using String = std::string;

	using Size = std::size_t;
	using Int32 = int32_t;
	using UInt = unsigned int;
	using UInt32 = uint32_t;

	// Filesystem
	// using Path = std::filesystem::path;

	// Math
	using Vec2 = glm::vec2;
	using Vec3 = glm::vec3;
	using Vec4 = glm::vec4;

	using Vec2i = glm::ivec2;
	using Vec3i = glm::ivec3;
	using Vec4i = glm::ivec4;

	String Replace(String haystack, const String needle, const String replacement);

	template <typename Out>
	void Split(const String& s, char delim, Out result) {
		std::istringstream iss(s);
		String item;
		while (std::getline(iss, item, delim)) {
			*result++ = item;
		}
	}
	Vector<String> Split(const String& s, char delim);

	template<typename T, typename... Args>
	SharedPtr<T> MakeShared(Args&&... args)
	{
		return std::make_shared<T>(std::forward<Args>(args)...);
	}
}