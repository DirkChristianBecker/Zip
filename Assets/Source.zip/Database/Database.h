#pragma once

#include <stdio.h>
#include <sqlite3.h>

namespace Yage
{
	/// <summary>
	/// This class is a wrapper around the C-API of Sqlite3.
	/// 
	/// </summary>
	class Database
	{
	private:

	protected:

	public:

	};
}